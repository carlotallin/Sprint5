package cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.domain;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "USERS")
public class User {

	//FIELDS
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	//@Column(name = "ID")
	private int id;
	
	@Column(name = "Username")
	private String username;

	@Column(name = "Register Date")
	private LocalDate registerDate;

	@Column(name = "% Wins")
	private int percentWins;
	
	@OneToMany(fetch = FetchType.EAGER, mappedBy="user", cascade = CascadeType.ALL)
	@JsonIgnoreProperties("user")
	private List<Game> roundsList;
	
	//CONSTRUCTOR
	public User() {
		roundsList = new ArrayList<Game>();
		registerDate = LocalDate.now();
	}
	
	//GETTERS AND SETTERS
	public int getId() {
		return id;
	}
	public String getUsername() {
		return username;
	}
	public LocalDate getRegisterDate() {
		return registerDate;
	}
	public List<Game> getRoundsList() {
		return roundsList;
	}
	public int getPercentWins() {
		return percentWins;
	}
	
	public void setPercentWins(int percentWins) {
		this.percentWins = percentWins;
	}
	public void setRoundsList(List<Game> roundsList) {
		this.roundsList = roundsList;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public void setPercentWins(){
		percentWins = calculateAverageWin();
	}	
	public void setRegisterDate(LocalDate registerDate) {
		this.registerDate = registerDate;
	}

	//TO STRING
	@Override
	public String toString() {
		return super.toString();
	}

	//METHODS
	public void eraseRoundList () {
		roundsList.removeAll(roundsList);
	}

	public void addGame (Game game) {
		roundsList.add(game);
	}
	  
	public int calculateAverageWin () {
		int wins = 0;
		int games = roundsList.size(); //SI AFAGEIXO +1 EL % ÉS CORRECTE
		int result;
		if (roundsList.isEmpty()) {
			result=0;
		}
		else{ 
			for (Game game: roundsList){
                if (game.getResult().equalsIgnoreCase("WIN")){
                    wins++;
                }
			}
			result = (wins*100)/games;
		}
		return result;
	}
}
