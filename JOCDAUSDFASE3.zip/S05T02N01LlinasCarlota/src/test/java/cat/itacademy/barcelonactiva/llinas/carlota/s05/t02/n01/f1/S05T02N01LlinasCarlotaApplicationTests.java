package cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S05T02N01LlinasCarlotaApplicationTests {

	@Test
	void contextLoads() {
	}

}
