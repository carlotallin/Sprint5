package cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.controller;

import java.text.DecimalFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.domain.Game;
import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.domain.User;
import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.services.GameService;
import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.services.UserService;

@CrossOrigin(origins = "http://localhost:9000")
@Controller
@RequestMapping(value="/players")
public class GameController {

	@Autowired
	GameService gameService;
	@Autowired
	UserService userService;
	
	@GetMapping("/home")
    public ModelAndView home() {
        ModelAndView mav = new ModelAndView("home");
        return mav;
    }
	
	// Method to CREATE USER
	@GetMapping("/add")
    public ModelAndView addPlayer() {
		ModelAndView mav = new ModelAndView("newUser");
		User user = new User();
		mav.addObject("user", user);
		return mav;
    }
	
	// Method to SAVE USER in Repository + Start Game templete 
	@PostMapping("/save")
	public ModelAndView guardar(@ModelAttribute User user) {
		User existingUser = userService.findByUsername(user.getUsername());
		if (existingUser==null) {
			userService.add(user);
			ModelAndView mav = new ModelAndView("startGame");
			return mav;
		}
		else {
			ModelAndView mav2 = new ModelAndView("RepeatedUser"); 
			return mav2;
		}	
	}
	
	// Method to UPDATE USER. Modifies name.
	@GetMapping("/update/{username}")
    public ModelAndView update(@PathVariable String username) {
		ModelAndView mav = new ModelAndView("updateName");
		User user = userService.findByUsername(username);
		mav.addObject("user", user);
		return mav;		
    }
	
	//Method to PLAY GAME
	@GetMapping("/games/playing/{username}")
	public ModelAndView game (@PathVariable String username) {
		ModelAndView mav = new ModelAndView("game");
		User user = userService.findByUsername(username);
		Game game = new Game(user);
		//Add game to User gameList
		user.addGame(game);
		//Set new % WINS
		user.setPercentWins();
		gameService.save(game);
		mav.addObject("game",game);
		mav.addObject("user", user);
		return mav;	
	}
	
	//Method to DELETE GAMES
	@GetMapping("/{username}/games/delete")
	public ModelAndView delete(@PathVariable String username) {
		User user = userService.findByUsername(username);
		gameService.deleteUserGames(user);
		ModelAndView mav = home();
		return mav;
	}
	
	//Method to GET ALL PLAYERS + % WINS
	@GetMapping("/getAll")
	public ModelAndView getAll(){
		List<User> list = userService.getAll();
		if (list.isEmpty()) {
			ModelAndView mav = new ModelAndView("getAllEmpty");				
			return mav;
		} 
		else {
			ModelAndView mav = new ModelAndView("getAllPlayers");
	        mav.addObject("listUsers",list);   
	        return mav;
		}
	}
	
	//Method getRounds of a specific USER.
	@GetMapping("/{username}/gameslist")
	public ModelAndView getRounds(@PathVariable String username){
		User user = userService.findByUsername(username);
		List<Game> gamesList = user.getRoundsList();
		ModelAndView mav = new ModelAndView("getAllGames");	
		mav.addObject("user",user);
		mav.addObject("gamesList", gamesList);
		return mav;
	}
	
	//Method to get RANKING
	@GetMapping("/ranking")
	public ModelAndView getRanking(){
		ModelAndView mav = new ModelAndView("getRanking");
		//Limit decimal to 2 numbers
		DecimalFormat df = new DecimalFormat("#.##");
		float ranking = userService.getRanking();
		mav.addObject("ranking",df.format(ranking));
		return mav;
	}
	
	//Method to get LOSER
	@GetMapping("/ranking/loser")
	public ModelAndView getLoser(){
		User user = userService.getLoser();
		ModelAndView mav;
		if(user == null) {
			mav = new ModelAndView("getAllEmpty");
		}
		else {
			mav = new ModelAndView("getLoser");
			mav.addObject("user",user);
		}
		return mav;
	}
	
	//Method to get WINNER
	@GetMapping("/ranking/winner")
	public ModelAndView getWinner(){
		User user = userService.getWinner();
		ModelAndView mav;
		if(user == null) {
			mav = new ModelAndView("getAllEmpty");
		}
		else {
			mav = new ModelAndView("getWinner");
			mav.addObject("user",user);
		}
		return mav;
	}
}