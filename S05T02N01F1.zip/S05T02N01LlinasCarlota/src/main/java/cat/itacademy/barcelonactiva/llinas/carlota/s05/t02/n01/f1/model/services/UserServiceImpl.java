package cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.domain.User;
import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserRepository userRepo;

	//METHODS
	@Override
	public List<User> listUsers() {
		return userRepo.findAll();
	}
	
	@Override
	public List<User> getAll() {
		List<User> resultat = new ArrayList<User>(); 
		List<User> users = userRepo.findAll();
		if (users != null && users.size()>0) {
			for(User user: users) {
				resultat.add(user);
			}
		}
		return resultat;
	}
	
	@Override
	public User add(User user) {
		userRepo.save(user);
		return user;
	}

	@Override
	public User findByUsername(String username) {
		User user = userRepo.findByUsername(username);
		return user;
	}
	
	@Override
	public float getRanking() {	
		List<User> usersList = userRepo.findAll();
		float ranking = 0;
		int rankingUser = 0;		
		for (int i=0; i<usersList.size(); i++){
			User user = usersList.get(i);
			rankingUser = user.getPercentWins();
			ranking += rankingUser;
		}
		ranking = ranking/usersList.size();
		return ranking;	
	}
	
	@Override
	public User getLoser() {	
		List<User> usersList = userRepo.findAll();
		User looser;
		if(usersList.isEmpty()) {
			looser = null;
		}
		else {
			looser = usersList.get(0);	
			for (int i=0; i<usersList.size(); i++){
				User user = usersList.get(i);
				if (looser.getPercentWins()>= user.getPercentWins()) {
					looser = user;
				}
			}		
		}
		return looser;		
	}
		
	
	@Override
	public User getWinner() {	
		List<User> usersList = userRepo.findAll();
		User winner;
		if(usersList.isEmpty()) {
			winner= null;	
		}
		else {
			winner = usersList.get(0);
			for (int i=0; i<usersList.size(); i++){
				User user = usersList.get(i);
				if (winner.getPercentWins()<= user.getPercentWins()) {
					winner = user;
				}
			}
		}
		return winner;			
	}
}