package cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import javax.persistence.Transient;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "GAME")
public class Game {

	@Transient
	public static final String SEQUENCE_NAME = "tirades_sequence";
	
	//FIELDS
	@Id
	private int idGame;
	
	private int dice1;

	private int dice2;

	private String result;

	private User user;
	
	//CONSTRUCTOR
	public Game () {
		
	}
	
	public Game(User user) {
		dice1 = setDice1();
		dice2 = setDice2();
		result = setResult();
		this.user = user;
	}
	
	//GETTERS AND SETTERS
	public int getIdGame() {
		return idGame;
	}
	public int getDice1() {
		return dice1;
	}
	public int getDice2() {
		return dice2;
	}
	public String getResult() {
		return result;
	}
	public User getUser() {
		return user;
	}
	public int setDice1() {
		return this.dice1 = (int) Math.floor(Math.random() *(6 - 1 + 1) + 1);
	}
	public int setDice2() {
		return this.dice2 = (int) Math.floor(Math.random() *(6 - 1 + 1) + 1);
	}
	public String setResult() {
		String answer = "LOST";
		if (dice1 + dice2 == 7) {
			answer = "WIN";
		}
		return answer;
	}
	public void setIdGame(int idGame) {
		this.idGame = idGame;
	}

	@Override
	public String toString() {
		return "DICE 1: " + dice1 + " - DICE 2: " + dice2 + " - RESULT: " + result + ".";
	}
}
