package cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.domain;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.stereotype.Component;

@Document(collection = "database_sequences")
@Component
public class Sequence {
	//esta clase sirve para que haya un id autoincremental numerico para evitar el tipo de
	//id que da mongo que suele dar comflicto
    @Id
    private String id;

    private int seq;

    public Sequence() {
	}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getSeq() {
        return seq;
    }

    public void setSeq(int seq) {
        this.seq = seq;
    }
}


