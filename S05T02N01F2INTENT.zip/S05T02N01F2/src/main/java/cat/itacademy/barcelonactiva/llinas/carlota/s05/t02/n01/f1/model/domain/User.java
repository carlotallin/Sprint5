package cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.Transient;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "USER")
public class User {

	//FIELDS
	@Transient
	public static final String SEQUENCE_NAME = "users_sequence";
	
	@Id
	private int id;

	@Indexed(unique = true)
	private String username;

	private LocalDate registerDate;

	private int percentWins;
	
	private List<Game> roundsList;
	
	public static int number=0;
	    
	//CONSTRUCTOR
	public User() {
		roundsList = new ArrayList<Game>();
		registerDate = LocalDate.now();
	}
	
	//GETTERS AND SETTERS
	public int getId() {
		return id;
	}
	public String getUsername() {
		return username;
	}
	public LocalDate getRegisterDate() {
		return registerDate;
	}
	public List<Game> getRoundsList() {
		return roundsList;
	}
	public int getPercentWins() {
		return percentWins;
	}
	
	public void setPercentWins(int percentWins) {
		this.percentWins = percentWins;
	}
	public void setRoundsList(List<Game> roundsList) {
		this.roundsList = roundsList;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public void setPercentWins(){
		percentWins = calculateAverageWin();
	}	
	public void setRegisterDate(LocalDate registerDate) {
		this.registerDate = registerDate;
	}

	//TO STRING
	@Override
	public String toString() {
		return super.toString();
	}

	//METHODS
	public void eraseRoundList () {
		roundsList.removeAll(roundsList);
	}

	public void addGame (Game game) {
		roundsList.add(game);
	}
	  
	public int calculateAverageWin () {
		int wins = 0;
		int games = roundsList.size(); //SI AFAGEIXO +1 EL % ÉS CORRECTE
		int result;
		if (roundsList.isEmpty()) {
			result=0;
		}
		else{ 
			for (Game game: roundsList){
                if (game.getResult().equalsIgnoreCase("WIN")){
                    wins++;
                }
			}
			result = (wins*100)/games;
		}
		return result;
	}
}
