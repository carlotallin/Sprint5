package cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.services;

import java.util.List;

import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.domain.Game;
import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.domain.User;

public interface GameService {

	public Game save(Game game);
	public List<Game> listGames();
	public void deleteUserGames(User user);

}
