package cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.services;


import static org.springframework.data.mongodb.core.query.Query.query;
import java.util.Objects;
import static org.springframework.data.mongodb.core.FindAndModifyOptions.options;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.domain.Sequence;

import static org.springframework.data.mongodb.core.query.Criteria.where;

@Service
public class SequenceService {

	//este service es para generar el id incremetal comentado en el modelo

		@Autowired
	    private  MongoOperations mongoOperations;

	    @Autowired
	    public SequenceService(MongoOperations mongoOperations) {
	        this.mongoOperations = mongoOperations;
	    }

	    public  int generateSequence(String seqName) {

	        Sequence counter = mongoOperations.findAndModify(query(where("_id").is(seqName)),
	                new Update().inc("seq",1), options().returnNew(true).upsert(true),
	                Sequence.class);
	        return !Objects.isNull(counter) ? counter.getSeq() : 1;

	    }

}
