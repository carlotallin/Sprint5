package cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.domain.Game;
import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.domain.User;
import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.repository.GameRepository;

@Service
public class GameServiceImpl implements GameService {
	
	@Autowired
	GameRepository gameRepo;
	
	//METHODS
	@Override
	public List<Game> listGames() {
		List<Game> resultat = gameRepo.findAll();
		return resultat;
	}

	@Override
	public Game save(Game game) {
		gameRepo.save(game);
		return game; 
	}
	
	@Override
	public void deleteUserGames(User user) {
		List<Game> list = gameRepo.findAll();
		for (int i = 0; i<list.size(); i++) {	
			if (user == list.get(i).getUser()) {
				int idGame= list.get(i).getIdGame();
				gameRepo.deleteById(idGame);
			}		
		}
	}
}