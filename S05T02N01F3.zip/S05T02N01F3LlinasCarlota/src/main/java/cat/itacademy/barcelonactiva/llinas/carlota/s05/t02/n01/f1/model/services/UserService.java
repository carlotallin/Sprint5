package cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.services;

import java.util.List;

import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.domain.User;

public interface UserService {

	public List<User> listUsers();
	public List<User> getAll();
	public User add(User user);
	public User findByUsername(String username);
	public float getRanking();
	public User getLoser();
	public User getWinner();

}
