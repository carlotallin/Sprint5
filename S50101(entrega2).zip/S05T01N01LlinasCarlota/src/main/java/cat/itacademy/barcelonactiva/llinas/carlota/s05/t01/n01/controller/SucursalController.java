package cat.itacademy.barcelonactiva.llinas.carlota.s05.t01.n01.controller;

// LINKS USED: https://www.tutorialspoint.com/postman/postman_post_requests.htm
// https://www.bezkoder.com/spring-boot-jpa-h2-example/

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import cat.itacademy.barcelonactiva.llinas.carlota.s05.t01.n01.model.domain.Sucursal;
import cat.itacademy.barcelonactiva.llinas.carlota.s05.t01.n01.model.dto.SucursalDTO;
import cat.itacademy.barcelonactiva.llinas.carlota.s05.t01.n01.model.services.SucursalService;

@CrossOrigin(origins = "http://localhost:9000")
@RestController
@RequestMapping(value="/sucursal")
public class SucursalController {

	@Autowired
	SucursalService sucursalService;
	
	@GetMapping("/home")
    public ModelAndView index() {
        ModelAndView mav = new ModelAndView("index");
        mav.addObject("listSucursales", sucursalService.getAll());
        return mav;
    }
	 
	@GetMapping("/add")
	public ModelAndView add() {
        ModelAndView mav = new ModelAndView("newSucursal");
		Sucursal sucursal = new Sucursal();
		mav.addObject("sucursal", sucursal);
		return mav;
	}
	
	@PostMapping("/save")
	public ModelAndView guardar(@ModelAttribute SucursalDTO sucursal) {
		sucursalService.add(sucursal);
		ModelAndView mav = index();
		return mav;			
	}

	@GetMapping("/update/{id}")
    public ModelAndView update(@PathVariable Integer id) {
		ModelAndView mav = new ModelAndView("updateSucursal");
		SucursalDTO sucursalDTO = sucursalService.getOne(id);
		mav.addObject("sucursalDTO", sucursalDTO);
		return mav;		
    }
	
	@GetMapping("/delete/{id}")
	public ModelAndView delete(@PathVariable Integer id) {
		sucursalService.delete(id);
		ModelAndView mav = index();
		return mav;
	}

	@GetMapping("/getOne/{id}")
	public ModelAndView getOne(@PathVariable int id) {
		SucursalDTO sucursalDTO = sucursalService.getOne(id);		
		ModelAndView mav = new ModelAndView("getOne");
        mav.addObject("sucursal", sucursalDTO);
        return mav;
				 
	}
	 
	@GetMapping("/getAll")
	public ModelAndView getAll(){
		List<SucursalDTO> list = sucursalService.getAll();
		if (list.isEmpty()) {
			ModelAndView mav = new ModelAndView("getAllEmpty");				
			return mav;
		} 
		else {
			ModelAndView mav = new ModelAndView("getAll");
	        mav.addObject("listSucursales",list);
	        return mav;
		}
	}
	
}
