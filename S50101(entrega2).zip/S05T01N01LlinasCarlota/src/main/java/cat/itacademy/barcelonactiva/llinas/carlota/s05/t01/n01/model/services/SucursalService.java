package cat.itacademy.barcelonactiva.llinas.carlota.s05.t01.n01.model.services;

import java.util.List;

import cat.itacademy.barcelonactiva.llinas.carlota.s05.t01.n01.model.domain.Sucursal;
import cat.itacademy.barcelonactiva.llinas.carlota.s05.t01.n01.model.dto.SucursalDTO;

public interface SucursalService {

	public Sucursal add(SucursalDTO sucursalDTO);
	public SucursalDTO update(SucursalDTO sucursalDTO, int id);
	public void delete(int id);
	public SucursalDTO getOne(int id);
	public List<SucursalDTO> getAll();

}