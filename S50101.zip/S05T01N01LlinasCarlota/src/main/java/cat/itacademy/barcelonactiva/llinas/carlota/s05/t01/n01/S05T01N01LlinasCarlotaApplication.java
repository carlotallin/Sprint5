package cat.itacademy.barcelonactiva.llinas.carlota.s05.t01.n01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S05T01N01LlinasCarlotaApplication {

	public static void main(String[] args) {
		SpringApplication.run(S05T01N01LlinasCarlotaApplication.class, args);
	}
	

}
