package cat.itacademy.barcelonactiva.llinas.carlota.s05.t01.n01.controller;

// LINKS USED: https://www.tutorialspoint.com/postman/postman_post_requests.htm
// https://www.bezkoder.com/spring-boot-jpa-h2-example/

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cat.itacademy.barcelonactiva.llinas.carlota.s05.t01.n01.model.domain.Sucursal;
import cat.itacademy.barcelonactiva.llinas.carlota.s05.t01.n01.model.dto.SucursalDTO;
import cat.itacademy.barcelonactiva.llinas.carlota.s05.t01.n01.model.services.SucursalService;

@CrossOrigin(origins = "http://localhost:9000")
@RestController
@RequestMapping(value="/sucursal")
public class SucursalController {

	@Autowired
	SucursalService sucursalService;
	
	@PostMapping("/add")
	public ResponseEntity<String> add(@RequestBody SucursalDTO sucursalDTO) {	
		try {
			Sucursal sucursal = sucursalService.add(sucursalDTO);			
			return new ResponseEntity<>("\n*** Sucursal añadida *** \n\n" + sucursal.toString() , HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}	
	}
	
	@PutMapping("/update/{id}")
	public ResponseEntity<String> update(@RequestBody SucursalDTO sucursalDTO, @PathVariable Integer id) {
	
		try {
			SucursalDTO sucursalUpdated = sucursalService.update(sucursalDTO, id);
			if (sucursalUpdated == null) {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			} 
			else {
				return new ResponseEntity<>("\n*** Sucursal updated *** \n" + sucursalService.toString(), HttpStatus.OK);
			} 
		} catch (Exception e) {
			return new ResponseEntity<>("\n*** There has been an error, try again! ***", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> delete(@PathVariable Integer id) {
		try {
			SucursalDTO sucursal = sucursalService.getOne(id);
			if (sucursal != null) {
				sucursalService.delete(id);
				return new ResponseEntity<String>("\n*** Sucursal borrada *** \n\n" + sucursal.toString(), HttpStatus.OK);
			} 
			else {
				return new ResponseEntity<String>("\n*** Esta sucursal no existe! ***", HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			return new ResponseEntity<String>("\n*** ERROR ***", HttpStatus.INTERNAL_SERVER_ERROR);
		}		
	}
	
	@GetMapping("/getOne/{id}")
	public ResponseEntity<SucursalDTO> getOne(@PathVariable int id){
		try {
			SucursalDTO sucursalDTO = sucursalService.getOne(id);
			if (sucursalDTO == null) {
				return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
			} 
			else {			
				return new ResponseEntity<>(sucursalDTO, HttpStatus.OK);
			}		
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/getAll")
	public ResponseEntity<List<SucursalDTO>> getAll(){
		try {
			List<SucursalDTO> list = sucursalService.getAll();
			if (list.isEmpty()) {
				return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
			} 
			else {
				return new ResponseEntity<List<SucursalDTO>>(list, HttpStatus.OK);
			}			
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}	
	}
}
