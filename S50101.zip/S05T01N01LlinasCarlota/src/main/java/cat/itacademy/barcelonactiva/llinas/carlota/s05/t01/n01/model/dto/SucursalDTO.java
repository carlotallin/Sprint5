package cat.itacademy.barcelonactiva.llinas.carlota.s05.t01.n01.model.dto;

import java.util.Arrays;
import java.util.List;

public class SucursalDTO {
	
	private int pk_SucursalID;
	private String nombreSucursal;
	private String paisSucursal;
	private String tipusSucursal;
	
	String[] listaPaisesUE = { "Alemania", "Belgica", "Croacia", "Dinamarca", "España", "Francia", "Irlanda", "Letonia",
			"Luxemburgo", "Paises Bajos", "Suecia", "Bulgaria", "Eslovaquia", "Estonia", "Grecia", "Malta", "Polonia",
			"Republica Checa", "Austria", "Chipre", "Eslovenia", "Finlandia", "Hungria", "Italia", "Lituania",
			"Portugal", "Rumania" };
	List<String> paisesEU = Arrays.asList(listaPaisesUE);

	public int getPk_SucursalID() {
		return pk_SucursalID;
	}

	public void setPk_SucursalID(int pk_SucursalID) {
		this.pk_SucursalID = pk_SucursalID;
	}

	public String getNombreSucursal() {
		return nombreSucursal;
	}

	public void setNombreSucursal(String nomSucursal) {
		this.nombreSucursal = nomSucursal;
	}

	public String getPaisSucursal() {
		return paisSucursal;
	}

	public void setPaisSucursal(String paisSucursal) {
		this.paisSucursal = paisSucursal;
	}

	public String getTipusSucursal() {
		return tipusSucursal;
	}

	public void setTipusSucursal(String tipusSucursal) {
		this.tipusSucursal = tipusSucursal;
	}

	public String getTipusSucursal(String pais) {
		this.tipusSucursal = "N/A";
		int indice = paisesEU.indexOf(pais);
		if (indice != -1) {
			this.tipusSucursal = "EU";
		} else {
			this.tipusSucursal = "Fuera EU";
		}
		return this.tipusSucursal;
	}
	
	@Override
	public String toString() {
		return "Sucursal ID = " + pk_SucursalID + ", Nombre = " + nombreSucursal + ", Pais = "+ paisSucursal + ", UE/ NO UE: " + tipusSucursal +".";	
	}

}
