package cat.itacademy.barcelonactiva.llinas.carlota.s05.t01.n01.model.services;

import java.util.List;
import java.util.Optional;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cat.itacademy.barcelonactiva.llinas.carlota.s05.t01.n01.model.domain.Sucursal;
import cat.itacademy.barcelonactiva.llinas.carlota.s05.t01.n01.model.dto.SucursalDTO;
import cat.itacademy.barcelonactiva.llinas.carlota.s05.t01.n01.model.repository.SucursalRepository;

@Service
public class SucursalServiceImpl implements SucursalService {
	
	@Autowired
	SucursalRepository sucursalRepo;

	public List<Sucursal> listSucursales() {
		return sucursalRepo.findAll();
	}
	
	@Override
	public Sucursal add(SucursalDTO sucursalDTO) {
		Sucursal sucursal = this.mapDTOToEntity(sucursalDTO);
		sucursalRepo.save(sucursal);
		
		return sucursal;
	}

	@Override
	public SucursalDTO update(SucursalDTO sucursalDTO, int id) {
		@SuppressWarnings("deprecation")
		Sucursal sucursalOld = sucursalRepo.getById(id);
		
		sucursalOld.setNombreSucursal(sucursalDTO.getNombreSucursal());
		sucursalOld.setPaisSucursal(sucursalDTO.getPaisSucursal());
		sucursalRepo.save(sucursalOld);		
		SucursalDTO sucursalUpdated = this.mapEntityToDTO(sucursalOld);
		
		return sucursalUpdated;
	}

	@Override
	public void delete(int id) {
		sucursalRepo.deleteById(id);
	}

	@Override
	public SucursalDTO getOne(int id) {
		Optional<Sucursal> sucursal = sucursalRepo.findById(id);
		SucursalDTO sucursalDTO = null;
		if(sucursal != null) {
			Sucursal resultat = sucursal.get();
			sucursalDTO = this.mapEntityToDTO(resultat);
		}
		return sucursalDTO;
	}

	@Override
	public List<SucursalDTO> getAll() {
		List<SucursalDTO> resultat = new ArrayList<SucursalDTO>();
		List<Sucursal> sucursales = sucursalRepo.findAll();
		if (sucursales!=null && sucursales.size()>0) {
			for(Sucursal sucursal: sucursales) {
				resultat.add(this.mapEntityToDTO(sucursal));
			}
		}
		return resultat;
	}
	
	private Sucursal mapDTOToEntity(SucursalDTO sucursalDTO) {
		Sucursal resultat = null;
		if(sucursalDTO != null) {
			resultat = new Sucursal();
			resultat.setPk_SucursalID(sucursalDTO.getPk_SucursalID());
			resultat.setNombreSucursal(sucursalDTO.getNombreSucursal());
			resultat.setPaisSucursal(sucursalDTO.getPaisSucursal());
		}
		return resultat;
	}
	
	private SucursalDTO mapEntityToDTO(Sucursal sucursal) {
		SucursalDTO resultat = null;
		if(sucursal != null) {
			resultat = new SucursalDTO();
			resultat.setPk_SucursalID(sucursal.getPk_SucursalID());
			resultat.setNombreSucursal(sucursal.getNombreSucursal());
			resultat.setPaisSucursal(sucursal.getPaisSucursal());
			String pais=sucursal.getPaisSucursal();
			resultat.getTipusSucursal(pais);
		}
		return resultat;
	}


}