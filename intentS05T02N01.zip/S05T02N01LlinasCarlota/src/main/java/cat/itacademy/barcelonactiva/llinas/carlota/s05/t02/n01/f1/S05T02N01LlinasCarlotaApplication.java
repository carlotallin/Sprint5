package cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.thymeleaf.ThymeleafAutoConfiguration;

@SpringBootApplication(exclude= {ThymeleafAutoConfiguration.class,})
public class S05T02N01LlinasCarlotaApplication {

	public static void main(String[] args) {
		SpringApplication.run(S05T02N01LlinasCarlotaApplication.class, args);
	}

}
