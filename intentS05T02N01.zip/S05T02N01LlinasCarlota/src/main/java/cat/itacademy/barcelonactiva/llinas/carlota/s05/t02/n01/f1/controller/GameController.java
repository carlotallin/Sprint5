package cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.controller;

// LINKS USED: https://www.tutorialspoint.com/postman/postman_post_requests.htm
// https://www.bezkoder.com/spring-boot-jpa-h2-example/

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.domain.Game;
import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.domain.User;
import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.services.GameService;
import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.services.UserService;

@CrossOrigin(origins = "http://localhost:9000")
@Controller
@RequestMapping(value="/game")
public class GameController {

	@Autowired
	GameService gameService;
	UserService userService;
	
	@GetMapping("/home")
    public ModelAndView home() {
        ModelAndView mav = new ModelAndView("home");
        mav.addObject("listGames", gameService.listGames());
        mav.addObject("listUsers", userService.listUsers());
        return mav;
    }
	
	@GetMapping("/player/add")
    public ModelAndView addPlayer() {
		ModelAndView mav = new ModelAndView("newUser");
		User user = new User();
		mav.addObject("user", user);
		return mav;
    }
	
	@PostMapping("/player/save")
	public ModelAndView guardar(@ModelAttribute User user) {
		userService.add(user);
		ModelAndView mav = home();
		return mav;			
	}
	
	@GetMapping("/play/{username}")
	public ModelAndView play(@PathVariable String username) {	
	User user = userService.findByUsername(username);
	Game game = new Game(user);
	ModelAndView mav = new ModelAndView("game");
	mav.addObject("game",game);
	mav.addObject("user", user);
	return mav;
	}
	.
	/*
	@DeleteMapping("/deleteRounds/{id}")
	public ResponseEntity<String> deleteRounds(@PathVariable String userName) {
		try {
			User user = gameService.getUser(userName);
			if (user != null) {
				gameService.deleteRounds(userName);
				return new ResponseEntity<String>("\n*** User borrada *** \n\n", HttpStatus.OK);
			} 
			else {
				return new ResponseEntity<String>("\n*** Esta sucursal no existe! ***", HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			return new ResponseEntity<String>("\n*** ERROR ***", HttpStatus.INTERNAL_SERVER_ERROR);
		}		
	}
	
	@GetMapping("/user/{id}")
	public ResponseEntity<User> getUser(@PathVariable String userName){
		try {
			User user = gameService.getUser(userName);
			if (user == null) {
				return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
			} 
			else {			
				return new ResponseEntity<>(user, HttpStatus.OK);
			}		
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/getRounds/{id}")
	public ResponseEntity<List<Game>> getRounds(@PathVariable String userName){
		try {
			List<Game> list = gameService.getRounds(userName);
			if (list.isEmpty()) {
				return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
			} 
			else {
				return new ResponseEntity<List<Game>>(list, HttpStatus.OK);
			}			
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}	
	}*/
}
