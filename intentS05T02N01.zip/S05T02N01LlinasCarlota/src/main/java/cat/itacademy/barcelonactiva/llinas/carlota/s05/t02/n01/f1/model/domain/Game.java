package cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.domain;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "GAME")
public class Game {

	//FIELDS
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private int idGame;
	
	@Column (name = "Dice 1")
	private int dice1;

	@Column(name = "Dice 2")
	private int dice2;

	@Column(name = "Result")
	private String result;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "user_id",referencedColumnName="id")
	@JsonIgnoreProperties("gameList")
	private User user;
	
	//CONSTRUCTOR
	public Game () {}
	
	public Game(User user) {
		dice1 = setDice1();
		dice2 = setDice2();
		result = setResult();
		this.user = user;
	}
	
	//GETTERS AND SETTERS
	public int getIdGame() {
		return idGame;
	}
	public int getDice1() {
		return dice1;
	}
	public int getDice2() {
		return dice2;
	}
	public String getResult() {
		return result;
	}
	public User getUser() {
		return user;
	}


	public int setDice1() {
		return this.dice1 = (int) Math.floor(Math.random() *(6 - 1 + 1) + 1);
	}
	public int setDice2() {
		return this.dice2 = (int) Math.floor(Math.random() *(6 - 1 + 1) + 1);
	}
	public String setResult() {
		String answer = "LOST";
		if (dice1 + dice2 == 7) {
			answer = "WIN";
		}
		return answer;
	}

	@Override
	public String toString() {
		return "DICE 1: " + dice1 + " - DICE 2: " + dice2 + " - RESULT: " + result + ".";
	}
	


}
