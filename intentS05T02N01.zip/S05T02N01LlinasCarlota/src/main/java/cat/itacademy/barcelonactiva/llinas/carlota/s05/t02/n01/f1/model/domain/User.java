package cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.domain;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "USERS")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	//@Column(name = "ID")
	private int id;
	
	@Column(name = "Username")
	private String username;

	@Column(name = "Register Date")
	private Date registerDate;

	@Column(name = "% Wins")
	private int percentWins;
	
	@OneToMany(fetch = FetchType.EAGER, mappedBy="user", cascade = CascadeType.ALL)
	@JsonIgnoreProperties("user")
	private List<Game> roundsList = new ArrayList<>();
	
	public User() {}
	
	/*public User(String username) {
		this.username = username;
		//FALTA REGISTRATION DATE
		percentWins = 0;
		
	}*/
	
	//GETTERS AND SETTERS
	public int getId() {
		return id;
	}
	public String getUsername() {
		return username;
	}
	public Date getRegisterDate() {
		return registerDate;
	}
	public List<Game> getRoundsList() {
		return roundsList;
	}

	public void setId(int id) {
		this.id = id;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public void setRegisterDate(Date registerDate) {
		this.registerDate = registerDate;
	}
	public int getPercentWins() {
		return percentWins;
	}
	public void setPercentWins(int percentWins) {
		this.percentWins = percentWins;
	}
	
	//TO STRING
	@Override
	public String toString() {
		return super.toString();
	}

	//METHODS
	public void eraseRoundList () {
		roundsList.removeAll(roundsList);
	}


}
