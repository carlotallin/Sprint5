package cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.domain.Game;

@Repository
public interface GameRepository extends JpaRepository<Game, Integer> {

	Game save(Game game);

}

