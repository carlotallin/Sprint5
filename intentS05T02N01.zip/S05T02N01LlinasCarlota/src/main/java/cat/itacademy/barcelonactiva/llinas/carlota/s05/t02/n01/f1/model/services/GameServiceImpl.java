package cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.services;

import java.util.List;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.domain.Game;
import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.repository.GameRepository;

@Service
public class GameServiceImpl implements GameService {
	
	@Autowired
	GameRepository gameRepo;
	
	public List<Game> listGames() {
		List<Game> resultat = new ArrayList<Game>();
		resultat = gameRepo.findAll();
		return resultat;
	}

	@Override
	public Game save(Game game) {
		gameRepo.save(game);
		return game; 
	}
}