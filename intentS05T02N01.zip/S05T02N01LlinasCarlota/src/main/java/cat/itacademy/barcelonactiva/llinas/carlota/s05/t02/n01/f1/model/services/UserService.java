package cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.services;

import java.util.List;

import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.domain.User;

public interface UserService {

	public User add(User user);
	public User findByUsername(String username);
	public List<User> listUsers();
}
