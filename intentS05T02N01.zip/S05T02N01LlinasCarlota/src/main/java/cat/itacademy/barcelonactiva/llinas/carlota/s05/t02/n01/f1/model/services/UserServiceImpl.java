package cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.domain.Game;
import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.domain.User;
import cat.itacademy.barcelonactiva.llinas.carlota.s05.t02.n01.f1.model.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserRepository userRepo;

	public List<User> listUsers() {
		return userRepo.findAll();
	}
	/*@Override
	public List<User> getAll() {
		List<User> resultat = listUsers();
		if (resultat != null && sucursales.size()>0) {
			for(Sucursal sucursal: sucursales) {
				resultat.add(this.mapEntityToDTO(sucursal));
			}
		}
		return resultat;
	}*/
	
	@Override
	public User add(User user) {
		userRepo.save(user);
		return user;
	}

	@Override
	public User findByUsername(String username) {
	User user = userRepo.findByUsername(username);
	return user;
	}

}